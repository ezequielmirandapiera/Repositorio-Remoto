﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Game.Elements;



namespace MarioBros.Elements.Objects
{
    public class Players : Base, IGravity
    {

        #region Objects
        private PlayerAction _action;
        private Direction _direction;

        public event EventHandler Died;
        #endregion

        #region Constructor
        public Players(Elements.Resources resources, Data.Object obj)
        {
            base.Image = resources.SpriteSheet;

            Size _recSize = new Size(resources.Map_Data.tilewidth, resources.Map_Data.tileheight);
            SourceRec_Small_Stand = base.Create_Rectangles(_recSize, new Point(320, 640));
            SourceRec_Small_Stop = base.Create_Rectangles(_recSize, new Point(384, 640));
            SourceRec_Small_Walk = base.Create_Rectangles(_recSize, new Point(416, 640), new Point(320, 672), new Point(352, 672));
            SourceRec_Small_Jump = base.Create_Rectangles(_recSize, new Point(384, 672));
            SourceRec_Small_Dead = base.Create_Rectangles(_recSize, new Point(352, 640));
            SourceRec_Small_Flag = base.Create_Rectangles(_recSize, new Point(320, 704));

            Action_State = PlayerAction.Idle;
            Direction_State = Direction.Right;

            this.FPS = 12;
            this.Velocity = PointF.Empty;
            this.MapPosition = new PointF(obj.x, (int)obj.y - resources.Map_Data.tileheight);
        }
        #endregion

        #region Properties
        public PlayerAction Action_State
        {
            get { return _action; }
            set
            {
                _action = value;
                SetSourceRectangle();
            }
        }
        /// <summary>
        /// Direccion hacia donde mira el personaje
        /// </summary>
        new public Direction Direction_State
        {
            get { return _direction; }
            set
            {
                _direction = value;
                SetSourceRectangle();
            }
        }

        private Rectangle[] SourceRec_Small_Stop { get; set; }
        private Rectangle[] SourceRec_Small_Run { get; set; }
        private Rectangle[] SourceRec_Small_Stand { get; set; }
        private Rectangle[] SourceRec_Small_Walk { get; set; }
        private Rectangle[] SourceRec_Small_Jump { get; set; }
        private Rectangle[] SourceRec_Small_Dead { get; set; }
        private Rectangle[] SourceRec_Small_Flag { get; set; }
        #endregion

        #region Methods
        /// <summary>
        /// Setea el valor del array de rectangulos que se va a dibujar
        /// </summary>
        private void SetSourceRectangle()
        {
            // dependiendo el estado nuevo del perosnaje reasigna el array de rectangulo que corresponda a SourceRectangle para que se dibuje correctamente
            if (Action_State == PlayerAction.Idle)
                SourceRectangles = SourceRec_Small_Stand;
            else if (Action_State == PlayerAction.Walk)
                SourceRectangles = SourceRec_Small_Walk;
            else if (Action_State == PlayerAction.Stop)
                SourceRectangles = SourceRec_Small_Stop;
            else if (Action_State == PlayerAction.Jump || Action_State == PlayerAction.Falling)
                SourceRectangles = SourceRec_Small_Jump;
            else if (Action_State == PlayerAction.Die)
                SourceRectangles = SourceRec_Small_Dead;
            else if (Action_State == PlayerAction.Flag)
                SourceRectangles = SourceRec_Small_Flag;

            ResetAnimation();
        }
        /// <summary>
        /// Interaccion con el personaje
        /// </summary>
        public void MoveCharacter()
        {
            if (this.Action_State == PlayerAction.Die)
                return;




        }
        /// <summary>
        /// Mata a mario bros
        /// </summary>
        public void Kill()
        {
            this.Action_State = PlayerAction.Die; // cambia el estado para mostrar el sprite correspondiente
            this.Velocity = new PointF(Velocity.X, -20); // cambia velocidad para mostrar el salto de muerte
            this.Died(this, EventArgs.Empty); // notifica al controlador del juego que mario murio para cambiar el estado del juego
        }
        #endregion

        #region Update
        public override void Update(GameTime gameTime)
        {
            this.MoveCharacter();

            base.Update(gameTime);
        }
        #endregion

        #region Draw
        public override void Draw(DrawHandler drawHandler)
        {
            drawHandler.Draw(base.Image, base.SourceRectangle, (int)base.Position.X, (int)base.Position.Y, Direction_State == Direction.Left);
        }
        #endregion
    }
    public enum PlayerAction // Diferentes tipos de acciones que puede realizar el personaje
    {
        Idle,
        Walk,
        Die,
        Flag,
        Jump,
        Falling,
        Stop,
    }
}



