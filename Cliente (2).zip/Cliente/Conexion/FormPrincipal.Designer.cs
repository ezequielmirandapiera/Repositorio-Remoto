﻿
namespace Conexion
{
    partial class FormPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Tiempo = new System.Windows.Forms.RadioButton();
            this.Top3 = new System.Windows.Forms.RadioButton();
            this.button2 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.DataView = new System.Windows.Forms.DataGridView();
            this.GridInvitados = new System.Windows.Forms.DataGridView();
            this.button6 = new System.Windows.Forms.Button();
            this.invitacion = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.time = new System.Windows.Forms.Label();
            this.clock = new System.Windows.Forms.Timer(this.components);
            this.button1 = new System.Windows.Forms.Button();
            this.Victorias = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.DataView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridInvitados)).BeginInit();
            this.SuspendLayout();
            // 
            // Tiempo
            // 
            this.Tiempo.AutoSize = true;
            this.Tiempo.Location = new System.Drawing.Point(41, 25);
            this.Tiempo.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Tiempo.Name = "Tiempo";
            this.Tiempo.Size = new System.Drawing.Size(98, 17);
            this.Tiempo.TabIndex = 0;
            this.Tiempo.TabStop = true;
            this.Tiempo.Text = "Tiempo jugado.";
            this.Tiempo.UseVisualStyleBackColor = false;
            // 
            // Top3
            // 
            this.Top3.AutoSize = true;
            this.Top3.Location = new System.Drawing.Point(41, 118);
            this.Top3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Top3.Name = "Top3";
            this.Top3.Size = new System.Drawing.Size(144, 17);
            this.Top3.TabIndex = 2;
            this.Top3.TabStop = true;
            this.Top3.Text = "Top 3 mejores jugadores.";
            this.Top3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(61, 174);
            this.button2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(98, 24);
            this.button2.TabIndex = 3;
            this.button2.Text = "Enviar";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(61, 241);
            this.button4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(98, 28);
            this.button4.TabIndex = 4;
            this.button4.Text = "Salir";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // DataView
            // 
            this.DataView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataView.Location = new System.Drawing.Point(398, 19);
            this.DataView.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.DataView.Name = "DataView";
            this.DataView.RowHeadersWidth = 62;
            this.DataView.RowTemplate.Height = 28;
            this.DataView.Size = new System.Drawing.Size(264, 127);
            this.DataView.TabIndex = 5;
            this.DataView.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataView_CellContentDoubleClick);
            // 
            // GridInvitados
            // 
            this.GridInvitados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GridInvitados.Location = new System.Drawing.Point(398, 251);
            this.GridInvitados.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.GridInvitados.Name = "GridInvitados";
            this.GridInvitados.RowHeadersWidth = 62;
            this.GridInvitados.RowTemplate.Height = 28;
            this.GridInvitados.Size = new System.Drawing.Size(264, 135);
            this.GridInvitados.TabIndex = 6;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(544, 169);
            this.button6.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(97, 34);
            this.button6.TabIndex = 7;
            this.button6.Text = "Invitar seleccionados";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // invitacion
            // 
            this.invitacion.Location = new System.Drawing.Point(404, 169);
            this.invitacion.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.invitacion.Name = "invitacion";
            this.invitacion.Size = new System.Drawing.Size(88, 34);
            this.invitacion.TabIndex = 8;
            this.invitacion.Text = "Invitar a todos a jugar.";
            this.invitacion.UseVisualStyleBackColor = true;
            this.invitacion.Click += new System.EventHandler(this.invitacion_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(474, 207);
            this.button7.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(93, 29);
            this.button7.TabIndex = 9;
            this.button7.Text = "Buscar Partida";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // time
            // 
            this.time.AutoSize = true;
            this.time.Location = new System.Drawing.Point(285, 289);
            this.time.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.time.Name = "time";
            this.time.Size = new System.Drawing.Size(42, 13);
            this.time.TabIndex = 10;
            this.time.Text = "Tiempo";
            // 
            // clock
            // 
            this.clock.Tick += new System.EventHandler(this.clock_Tick);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(61, 314);
            this.button1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(83, 26);
            this.button1.TabIndex = 11;
            this.button1.Text = "LogIn";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Victorias
            // 
            this.Victorias.AutoSize = true;
            this.Victorias.Location = new System.Drawing.Point(41, 72);
            this.Victorias.Margin = new System.Windows.Forms.Padding(2);
            this.Victorias.Name = "Victorias";
            this.Victorias.Size = new System.Drawing.Size(122, 17);
            this.Victorias.TabIndex = 1;
            this.Victorias.TabStop = true;
            this.Victorias.Text = "Numero de victorias.";
            this.Victorias.UseVisualStyleBackColor = true;
            // 
            // FormPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Conexion.Properties.Resources.Iniciar1;
            this.ClientSize = new System.Drawing.Size(771, 387);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.time);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.invitacion);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.GridInvitados);
            this.Controls.Add(this.DataView);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Top3);
            this.Controls.Add(this.Victorias);
            this.Controls.Add(this.Tiempo);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "FormPrincipal";
            this.Text = "FormPrincipal";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.FormPrincipal_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DataView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridInvitados)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton Tiempo;
        private System.Windows.Forms.RadioButton Victorias;
        private System.Windows.Forms.RadioButton Top3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.DataGridView DataView;
        private System.Windows.Forms.DataGridView GridInvitados;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button invitacion;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label time;
        private System.Windows.Forms.Timer clock;
        private System.Windows.Forms.Button button1;
    }
}