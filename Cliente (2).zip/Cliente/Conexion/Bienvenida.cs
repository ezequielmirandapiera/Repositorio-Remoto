﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace Conexion
{
    public partial class Bienvenida : Form
    {

        int iniciadoConexion = 0;
        int contador = 0;
        Socket server;


        public Bienvenida()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            label1.Text = "LOADING";

            
            IPAddress direc = IPAddress.Parse("147.83.117.22");
            IPEndPoint ipep = new IPEndPoint(direc, 50057);
            //IPAddress direc = IPAddress.Parse("192.168.56.101");
            //IPEndPoint ipep = new IPEndPoint(direc, 9080);


            //Creamos el socket 
            server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                server.Connect(ipep);//Intentamos conectar el socket
                iniciadoConexion = 1;

            }
            catch (SocketException ex)
            {
                iniciadoConexion = 0;
            }


            timer1.Interval = 500;
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            if (label1.Text=="LOADING")
            {
                label1.Text = "LOADING.";
            }
            else if(label1.Text=="LOADING.")
            {
                label1.Text = "LOADING..";
            }
            else if(label1.Text=="LOADING...")
            {
                label1.Text = "LOADING";
            }
            else
            {
                label1.Text = "LOADING...";
            }

            

            if (contador == 10)
            {
                timer1.Stop();
                if (iniciadoConexion == 1)
                {
                    FormPrincipal principal = new FormPrincipal(server);
                    principal.Show();
                    this.Visible = false;
                    this.Hide();
                }
                else
                {
                    BadConn newErrorConexion = new BadConn();
                    newErrorConexion.Show();
                    Close();
                }
            }

            contador = contador + 1;

        }
    }
}
