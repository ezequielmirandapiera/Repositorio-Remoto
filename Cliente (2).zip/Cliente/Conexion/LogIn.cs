﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;

namespace Conexion
{
    public partial class LogIn : Form
    {
        string username;
        string password;
        Socket server;
        int iniciadoSesion = 0;
        public LogIn(Socket server)
        {
            InitializeComponent();
            Password.PasswordChar = '*';
            this.server = server;
        }

        public int getInit()
        {
            return iniciadoSesion;
        }
        public string getUsername()
        {
            return username;
        }
        public string getPassword()
        {
            return password;
        }
        public void getRespuesta1(int i)
        {
            if (i == 0)
            {
                MessageBox.Show("El username o la contraseña son incorrectos");
            }
            else
            {
                MessageBox.Show("Se ha iniciado sesión con exito");
                iniciadoSesion = 1;
            }
        }
        public void getRespuesta2()
        {
            MessageBox.Show("Este usuario ya esta conetado!!");
        }

        public void getRespuesta3(int i)
        {
            if (i == 0)
            {
                MessageBox.Show("El usuario se ha registrado.");
                iniciadoSesion = 1;
            }
            else
            {
                MessageBox.Show("No se ha registrado correctamente.");
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            if (iniciadoSesion == 0)
            {
                username = Username.Text;
                password = Password.Text;
                if (username.Length > 0 && password.Length > 0)
                {
                    // Enviamos nombre y password
                    string mensaje = "1/" + Username.Text + "/" + Password.Text;
                    // Enviamos al servidor el nombre tecleado
                    byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                    server.Send(msg);
                }
                else
                    MessageBox.Show("Escriba un username y un password!!");
            }
            else
                MessageBox.Show("Ya se ha iniciado sesión!!");

        }

        private void button5_Click(object sender, EventArgs e)
        {
            username = Username.Text;
            password = Password.Text;
            if (username.Length > 0 && password.Length > 0)
            {
                // Enviamos nombre y password
                string mensaje = "5/" + Username.Text + "/" + Password.Text;
                // Enviamos al servidor el nombre tecleado
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);
            }
            else
                MessageBox.Show("Escriba un username y un password!!");
        }
    }
}