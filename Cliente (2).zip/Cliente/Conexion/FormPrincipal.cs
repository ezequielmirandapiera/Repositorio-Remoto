﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using MarioBros;
using MarioBros.Elements.Map;

namespace Conexion
{
    public partial class FormPrincipal : Form
    {
        Socket server;
        Thread atender;
        delegate void DelegadoParaEscribir(string mensaje);
        delegate void DelegadoParaAceptar(string username, string YoN);
        delegate void DelegadoParaCerrar(); //Para poder cerrar el form LogIn.
        delegate void DelegadoParaLimpiar();
        string username;
        string password;
        string invitar = "10/";
        string invitar2;
        int numSel = 0;
        string[] players;
        LogIn Iniciar;
        public Demo Interfaz;

        //List<InterfazGrafica> formularios = new List<InterfazGrafica>();

        public FormPrincipal(Socket server)
        {
            InitializeComponent();
            this.server = server;
            //CheckForIllegalCrossThreadCalls = false; //Necesario para que los elementos de los formularios puedan
            //ser atendidos desde threads diferentes a los que los crearon.
        }
        int iniciadoSesion = 0; //variable que es '0' si todavia no hemos iniciado sesion o '1' si ya hemos iniciado sesion.
        int iniciadoConexion = 1; // variable que es '0' si no se ha iniciado la conexion con el servidor y '1' en caso contrario.
        int seleccionados; //variable que es '0' si la invitacion se hace a todos los jugadores o '1' si se hace solo a los seleccionados.

        int invitador = 0; // variable que sera 1 si has sido el invitador o 0 si eres el invitado.
        bool acepta = false; //Si todos han aceptado la partida.
        bool aceptaAnterior = true;
        bool creacionPartida = false; //cuando el tiempo para crear la partida o alguien rechaze la partida deja de crearla.
        bool creada = false; //Si se ha creado o no la partida
        int codigo;


        public void PonLista(string mensaje)
        {
            if (iniciadoConexion == 1)
            {
                DataView.Rows.Clear();
                DataView.ColumnCount = 1;
                DataView.ColumnHeadersVisible = true;
                if (mensaje != null)
                {
                    char delimiter = '/';
                    string[] division = mensaje.Split(delimiter);
                    int i = 0;
                    while (i < division.Length)
                    {
                        DataView.Rows.Add(division[i]);
                        i = i + 1;

                    }
                    DataView.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
                }
            }
        }

        public void Cerrar()
        {
            Iniciar.Close();
        }
        private void AtenderServidor()
        {
            while (true)
            {

                int v;
                String[] respuesta = new string[6];
                byte[] msg2 = new byte[80];
                server.Receive(msg2);
                string[] trozos = Encoding.ASCII.GetString(msg2).Split('/');
                this.codigo = Convert.ToInt32(trozos[0]);





                string mensaje;
                //MessageBox.Show("El codigo es: " + codigo);
                switch (codigo)
                {
                    case 1:
                        mensaje = trozos[1].Split('\0')[0];
                        int k = Convert.ToInt32(mensaje);
                        Iniciar.getRespuesta1(k);
                        if (k != 0)
                        {
                            DelegadoParaCerrar delegado2 = new DelegadoParaCerrar(Cerrar);
                            GridInvitados.Invoke(delegado2, new object[] { });
                        }
                        break;
                    case 2:
                        mensaje = trozos[1].Split('\0')[0];
                        MessageBox.Show(mensaje);

                        break;
                    case 3:
                        mensaje = trozos[1].Split('\0')[0];
                        MessageBox.Show(mensaje);

                        break;
                    case 4:
                        try
                        {
                            mensaje = "En la posición 1 tenemos al jugador de id= " + trozos[1] + " con " + trozos[2] + " puntos.";
                            MessageBox.Show(mensaje);
                            mensaje = "En la posición 2 tenemos al jugador de id= " + trozos[3] + " con " + trozos[4] + " puntos.";
                            MessageBox.Show(mensaje);
                            mensaje = "En la posición 3 tenemos al jugador de id= " + trozos[5] + " con " + trozos[6] + " puntos.";
                            MessageBox.Show(mensaje);
                        }
                        catch (IndexOutOfRangeException)
                        {
                            MessageBox.Show("No hay suficiente información para poder hacer esta consulta.");
                        }

                        break;
                    case 5:
                        mensaje = trozos[1].Split('\0')[0];
                        k = Convert.ToInt32(mensaje);
                        Iniciar.getRespuesta3(k);
                        if (k != 0)
                        {
                            DelegadoParaCerrar delegado2 = new DelegadoParaCerrar(Cerrar);
                            GridInvitados.Invoke(delegado2, new object[] { });
                        }
                        break;
                    case 6:
                        int longitud = trozos.Length;
                        int j = 3;
                        mensaje = trozos[2];
                        while (j < longitud)
                        {
                            mensaje = mensaje + "/" + trozos[j];
                            j = j + 1;
                        }
                        DelegadoParaEscribir delegado = new DelegadoParaEscribir(PonLista);
                        DataView.Invoke(delegado, new object[] { mensaje });
                        string invt = invitar;
                        string[] pieces = invt.Split('/');
                        int t = 1;
                        int l = 0;
                        while (t < pieces.Length - 1)
                        {
                            bool found = false;
                            while (found == false && l < DataView.RowCount)
                            {
                                string nombre2 = Convert.ToString(pieces[t]);
                                string nombre = Convert.ToString(DataView.Rows[l].Cells[0].Value);
                                if (nombre2 == nombre)
                                {
                                    found = true;
                                }
                                else
                                    l = l + 1;
                            }
                            if (found == true)
                            {
                                DataView.Rows[l].Cells[0].Style.BackColor = Color.Green;
                            }
                            t = t + 1;
                        }

                        break;
                    case 7: //llega una petición de invitación.
                        if (invitador == 0) // Si no eres tu el que has invitado...
                        {
                            DialogResult dialogResult = MessageBox.Show(username + ", ¿quieres unirte a una partida?", "Invitación", MessageBoxButtons.YesNo);
                            if (dialogResult == DialogResult.Yes) // Se acepta la partida.
                            {
                                string answer = "7/SI/" + username;
                                byte[] msg = System.Text.Encoding.ASCII.GetBytes(answer);
                                server.Send(msg);
                            }
                            else if (dialogResult == DialogResult.No) // Se rechaza la partida.
                            {
                                string answer = "7/NO/" + username;
                                byte[] msg = System.Text.Encoding.ASCII.GetBytes(answer);
                                server.Send(msg);
                            }
                        }
                        break;
                    case 8:
                        if (invitador == 1) // El que ha enviado la invitación atentedá esta petición, el resto no.
                        {
                            string username = trozos[1];
                            string YoN = trozos[2];
                            if (YoN == "NO")
                            {
                                aceptaAnterior = false;
                            }
                            else
                            {
                                acepta = true; // Se rechaza la partida.
                                invitar2 = invitar2 + username + "/";
                            }
                            if (aceptaAnterior == false)
                            {
                                acepta = false;
                            }
                            DelegadoParaAceptar delegado2 = new DelegadoParaAceptar(aceptarInvitacion);
                            GridInvitados.Invoke(delegado2, new object[] { username, YoN });
                        }
                        break;
                    case 9:
                        MessageBox.Show("No se ha podido crear la partida, los jugadores no han aceptado la partida.");
                        break;

                    case 10:
                        if (iniciadoSesion == 1)
                        {
                            string[] players_ = new string[trozos.Length - 2];
                            int i = 0;
                            while (i < players_.Length)
                            {
                                players_[i] = trozos[i + 1];
                                i = i + 1;
                            }
                            players = players_;
                            creada = true;
                            invitar2 = "";
                            invitar = "10/";
                            string message = "13/";
                            byte[] msg = System.Text.Encoding.ASCII.GetBytes(message);
                            server.Send(msg);
                            DelegadoParaLimpiar delegado3 = new DelegadoParaLimpiar(limpiar);
                            GridInvitados.Invoke(delegado3, new object[] { });
                            ThreadStart ts = delegate { PonerEnMarchaInterfaz(); };
                            Thread partida = new Thread(ts);
                            partida.Start();
                        }
                        break;

                    case 11:

                        if (trozos[1] == username)
                        {
                            MessageBox.Show("Enorabuena, has ganado la partida! :)");

                        }
                        else
                            MessageBox.Show("Ha ganado " + trozos[1] + " la partida! :(");


                        DelegadoParaCerrar delegado4 = new DelegadoParaCerrar(cerrarInterfaz);
                        GridInvitados.Invoke(delegado4, new object[] { });
                        break;


                    case 100:
                        Iniciar.getRespuesta2();
                        break;
                }
            }

        }
        public void cerrarInterfaz()
        {
            Interfaz.Cerrar();
        }
        public void limpiar()
        {
            GridInvitados.Rows.Clear();
        }
        private void PonerEnMarchaInterfaz()
        {
            
            Interfaz = new Demo(server, players, username);
            Interfaz.ShowDialog();
        }

        public void aceptarInvitacion(string username, string YoN)
        {
            string row = username + " ha aceptado la invitación? " + YoN;
            GridInvitados.Rows.Add(row);
            GridInvitados.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
            GridInvitados.ClearSelection();
        }
        /*
        private void button1_Click(object sender, EventArgs e) //crear conexion con el servidor
        {
            IPAddress direc = IPAddress.Parse("147.83.117.22");
            IPEndPoint ipep = new IPEndPoint(direc, 50057);
            //IPAddress direc = IPAddress.Parse("192.168.56.101");
            //IPEndPoint ipep = new IPEndPoint(direc, 9080);


            //Creamos el socket 
            server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                server.Connect(ipep);//Intentamos conectar el socket
                this.BackColor = Color.Green;
                iniciadoConexion = 1;
                MessageBox.Show("Conectado");

            }
            catch (SocketException ex)
            {
                //Si hay excepcion imprimimos error y salimos del programa con return 
                MessageBox.Show("No he podido conectar con el servidor");
                return;
            }
            //creamos el thread
            ThreadStart ts = delegate { AtenderServidor(); };
            atender = new Thread(ts);
            atender.Start();
        }*/

        private void button2_Click(object sender, EventArgs e)
        {
            if (iniciadoSesion == 1)
            {
                if (Tiempo.Checked)//peticion para saber el tiempo jugado
                {
                    string mensaje = "2/";
                    // Enviamos al servidor el nombre tecleado
                    byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                    server.Send(msg);
                }
                else if (Victorias.Checked)//peticion para saber el numero de victorias
                {
                    string mensaje = "3/";
                    // Enviamos al servidor el nombre tecleado
                    byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                    server.Send(msg);
                }
                if (Top3.Checked)//top 3 jugadores de la base de datos
                {
                    // Enviamos nombre y altura
                    string mensaje = "4/";
                    // Enviamos al servidor el nombre tecleado
                    byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                    server.Send(msg);
                }
            }
            else
                MessageBox.Show("Porfavor, inicie session.");


        }
        /*
        private void button3_Click(object sender, EventArgs e)//hacer el log in
        {

            if (iniciadoSesion == 0)
            {
                if (iniciadoConexion == 1)
                {
                    username = Username.Text;
                    password = Password.Text;
                    if (username.Length > 0 && password.Length > 0)
                    {
                        // Enviamos nombre y password
                        string mensaje = "1/" + Username.Text + "/" + Password.Text;
                        // Enviamos al servidor el nombre tecleado
                        byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                        server.Send(msg);
                    }
                    else
                        MessageBox.Show("Escriba un username y un password!!");
                }
                else
                    MessageBox.Show("Inicie conexión con el servidor!!");
            }
            else
            {
                MessageBox.Show("Ya se ha iniciado sesión");
            }

        } 

        private void button4_Click(object sender, EventArgs e)//desconectarse del servidor
        {
            if (iniciadoConexion == 1)
            {
                //Mensaje de desconexión
                string mensaje = "0/";

                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);

                // Nos desconectamos
                DataView.Rows.Clear();
                atender.Abort();
                this.BackColor = Color.Gray;
                iniciadoConexion = 0;
                iniciadoSesion = 0;
                server.Shutdown(SocketShutdown.Both);
                server.Close();
            
            else
                MessageBox.Show("Inicie conexión con el servidor!!");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (iniciadoConexion == 1)
            {
                username = Username.Text;
                password = Password.Text;
                // Enviamos nombre y password
                string mensaje = "5/" + Username.Text + "/" + Password.Text;
                // Enviamos al servidor el nombre tecleado
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);
            }
            else
                MessageBox.Show("Inicie conexión con el servidor!!");
        }
        */

        private void invitacion_Click(object sender, EventArgs e)
        {
            if (iniciadoSesion == 1 && creada == false && creacionPartida == false)
            {
                if (DataView.RowCount >= 3)
                {
                    if (DataView.RowCount <= 5)
                    {
                        aceptaAnterior = true;
                        seleccionados = 0;
                        clock.Start();
                        invitador = 1;
                        creacionPartida = true;
                        time.Text = "10";
                        //enviamos invitación
                        string mensaje = "6/";
                        byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                        server.Send(msg);

                        GridInvitados.Rows.Clear();
                        GridInvitados.ColumnCount = 1;
                        GridInvitados.GridColor = Color.Yellow;

                        DelegadoParaAceptar delegado = new DelegadoParaAceptar(aceptarInvitacion);
                        GridInvitados.Invoke(delegado, new object[] { username, "SI" });
                    }
                    else
                        MessageBox.Show("Hay demasiados usuarios conectados para poder jugar con todos.");
                }
                else
                    MessageBox.Show("No hay jugadores conectados para invitar.");
            }
            else
                MessageBox.Show("Porfavor, inicie session.");

        }
        private void FormPrincipal_Load(object sender, EventArgs e)
        {
            clock.Interval = 1000;
            ThreadStart ts = delegate { AtenderServidor(); };
            atender = new Thread(ts);
            atender.Start();
        }
        private void clock_Tick(object sender, EventArgs e)
        {
            int t = Convert.ToInt32(time.Text);
            t = t - 1;
            time.Text = Convert.ToString(t);

            if (t == 0)
            {
                if (invitar2 != null)
                {
                    string invt2 = invitar2;
                    string[] piece = invt2.Split('/');
                    if (numSel != piece.Length - 1)
                    {
                        acepta = false;
                    }
                }
                clock.Stop();
                creacionPartida = false;
                invitador = 0;
                if (seleccionados == 0)
                {
                    if (acepta == false)
                    {
                        time.Text = "Time";
                        // No se crea la partida. Avisar a todos los usuarios.
                        GridInvitados.Rows.Clear();
                        string mensaje = "8/";
                        byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                        server.Send(msg);
                    }
                    else if (acepta == true)
                    {
                        time.Text = "Time";
                        // Se crea la partida y, por lo tanto, se abren los tableros en todos los usuarios.
                        GridInvitados.Rows.Clear();
                        creada = true;
                        string mensaje = "9/";
                        byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                        server.Send(msg);
                    }
                }
                else
                {
                    if (acepta == false)
                    {
                        time.Text = "Time";
                        // No se crea la partida. Avisar a los usuarios seleccionados.
                        GridInvitados.Rows.Clear();
                        string mensaje = "11/" + invitar2 + username + "/";
                        byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                        server.Send(msg);
                        invitar2 = "";
                    }
                    else if (acepta == true)
                    {
                        time.Text = "Time";
                        // Se crea la partida y, por lo tanto, se abren los tableros en los usuarios seleccionados.
                        GridInvitados.Rows.Clear();
                        creada = true;
                        string mensaje = "12/" + invitar2 + username + "/";
                        byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                        server.Send(msg);
                    }
                }
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (iniciadoConexion == 1)
            {
                //Mensaje de desconexión
                string mensaje = "0/";

                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);

                // Nos desconectamos
                DataView.Rows.Clear();
                atender.Abort();
                this.BackColor = Color.Gray;
                iniciadoConexion = 0;
                iniciadoSesion = 0;
                server.Shutdown(SocketShutdown.Both);
                server.Close();
            }
        }


        private void button6_Click(object sender, EventArgs e)
        {
            if (iniciadoSesion == 1 && creada==false && creacionPartida==false)
            {
                if (numSel >= 1)
                {
                    aceptaAnterior = true;
                    seleccionados = 1;
                    clock.Start();
                    invitador = 1;
                    acepta = true;
                    creacionPartida = true;
                    time.Text = "10";

                    GridInvitados.Rows.Clear();
                    GridInvitados.ColumnCount = 1;
                    GridInvitados.GridColor = Color.Green;

                    DelegadoParaAceptar delegado = new DelegadoParaAceptar(aceptarInvitacion);
                    GridInvitados.Invoke(delegado, new object[] { username, "SI" });

                    byte[] msg = System.Text.Encoding.ASCII.GetBytes(invitar);
                    server.Send(msg);
                }
                else
                {
                    MessageBox.Show("Seleccione a algun jugador para poder invitar.");
                }
            }
            else
                MessageBox.Show("Porfavor, inicie session.");
        }

        private void DataView_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (creada == false && creacionPartida == false)
            {
                int r = e.RowIndex;
                int c = e.ColumnIndex;
                if (DataView.Rows[r].Cells[c].Value != null)
                {
                    string nombre = Convert.ToString(DataView.Rows[r].Cells[c].Value);
                    string[] piece = nombre.Split('\0');
                    if (piece[0] != username)
                    {
                        if (DataView.Rows[r].Cells[c].Style.BackColor == Color.Green)
                        {
                            string[] trozos = invitar.Split('/');
                            int i = 1;
                            string mensaje2 = "10/";
                            while (i < trozos.Length && trozos[i] != "")
                            {
                                nombre = Convert.ToString(DataView.Rows[r].Cells[c].Value);
                                piece = nombre.Split('\0');
                                if (trozos[i] != piece[0])
                                {
                                    mensaje2 = mensaje2 + trozos[i] + "/";
                                }
                                i = i + 1;
                            }
                            invitar = mensaje2;
                            DataView.Rows[r].Cells[c].Style.BackColor = Color.Gray;
                            numSel = numSel - 1;
                        }
                        else
                        {
                            nombre = Convert.ToString(DataView.Rows[r].Cells[c].Value);
                            piece = nombre.Split('\0');
                            invitar = invitar + piece[0] + "/";
                            DataView.Rows[r].Cells[c].Style.BackColor = Color.Green;
                            numSel = numSel + 1;
                        }
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Iniciar = new LogIn(server);
            Iniciar.ShowDialog();
            iniciadoSesion = Iniciar.getInit();
            username = Iniciar.getUsername();
            password = Iniciar.getPassword();
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {

        }
    }
}
